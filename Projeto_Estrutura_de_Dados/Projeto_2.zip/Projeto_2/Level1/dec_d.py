saindo = str('''
            Assustado, você simplesmente com um impulso inesplicável sai
            deste quarto, tentando entender melhor que lugar é esse.
''')
